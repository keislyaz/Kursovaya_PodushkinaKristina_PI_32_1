import { PointerEvent as ReactPointerEvent, useEffect, useRef, useState } from "react";

type Role = "teacher" | "student";
type Tool = "select" | "pen" | "pink" | "blue" | "line" | "rect" | "ellipse" | "eraser";
type DrawType = "path" | "line" | "rect" | "ellipse";
type Point = { x: number; y: number };
type BoardElement = {
  id: string;
  type: DrawType;
  points: Point[];
  width: number;
  color: string;
  opacity: number;
};
type BoardRoom = {
  code: string;
  access: boolean;
  elements: BoardElement[];
  updatedAt: number;
};
type Action =
  | { kind: "draw"; id: string }
  | { kind: "move"; id: string; start: Point; original: Point[] }
  | { kind: "resize"; id: string; bounds: Bounds; original: Point[] }
  | null;
type Bounds = { x: number; y: number; width: number; height: number };

const BOARD_WIDTH = 1200;
const BOARD_HEIGHT = 700;
const PEN_WIDTHS = [2, 4, 7, 11];

function roomKey(code: string) {
  return `assistutor-board-${code}`;
}

function readRoom(code: string): BoardRoom | null {
  const saved = localStorage.getItem(roomKey(code));
  return saved ? JSON.parse(saved) : null;
}

function boundsOf(element: BoardElement): Bounds {
  const xs = element.points.map((point) => point.x);
  const ys = element.points.map((point) => point.y);
  const x = Math.min(...xs);
  const y = Math.min(...ys);
  return {
    x,
    y,
    width: Math.max(Math.max(...xs) - x, 8),
    height: Math.max(Math.max(...ys) - y, 8),
  };
}

function pathData(points: Point[]) {
  return points.map((point, index) => `${index ? "L" : "M"} ${point.x} ${point.y}`).join(" ");
}

export default function Whiteboard({ role }: { role: Role }) {
  const [room, setRoom] = useState<BoardRoom | null>(null);
  const [codeInput, setCodeInput] = useState("");
  const [joinError, setJoinError] = useState("");
  const [tool, setTool] = useState<Tool>("pen");
  const [penWidth, setPenWidth] = useState(4);
  const [elements, setElements] = useState<BoardElement[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [action, setAction] = useState<Action>(null);
  const [copied, setCopied] = useState(false);
  const svgRef = useRef<SVGSVGElement>(null);
  const channelRef = useRef<BroadcastChannel | null>(null);
  const elementsRef = useRef<BoardElement[]>([]);

  const setLocalElements = (next: BoardElement[] | ((current: BoardElement[]) => BoardElement[])) => {
    setElements((current) => {
      const result = typeof next === "function" ? next(current) : next;
      elementsRef.current = result;
      return result;
    });
  };

  useEffect(() => {
    if (role !== "teacher") return;
    const activeCode = localStorage.getItem("assistutor-active-board");
    if (!activeCode) return;
    const saved = readRoom(activeCode);
    if (saved) {
      setRoom(saved);
      setLocalElements(saved.elements);
    }
  }, [role]);

  useEffect(() => {
    if (!room?.code) return;
    const channel = new BroadcastChannel(`assistutor-board-${room.code}`);
    channelRef.current = channel;
    const receive = (next: BoardRoom) => {
      setRoom(next);
      setLocalElements(next.elements);
      if (role === "student" && !next.access) setJoinError("Репетитор завершил доступ к этой доске");
    };
    channel.onmessage = (event: MessageEvent<BoardRoom>) => receive(event.data);
    const onStorage = (event: StorageEvent) => {
      if (event.key === roomKey(room.code) && event.newValue) receive(JSON.parse(event.newValue));
    };
    window.addEventListener("storage", onStorage);
    return () => {
      channel.close();
      window.removeEventListener("storage", onStorage);
    };
  }, [room?.code, role]);

  const publish = (next: BoardRoom) => {
    localStorage.setItem(roomKey(next.code), JSON.stringify(next));
    channelRef.current?.postMessage(next);
    setRoom(next);
  };

  const commitElements = (nextElements = elementsRef.current) => {
    if (!room) return;
    publish({ ...room, elements: nextElements, updatedAt: Date.now() });
  };

  const createRoom = () => {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    const next: BoardRoom = { code, access: false, elements: [], updatedAt: Date.now() };
    localStorage.setItem("assistutor-active-board", code);
    localStorage.setItem(roomKey(code), JSON.stringify(next));
    setRoom(next);
    setLocalElements([]);
  };

  const joinRoom = () => {
    const code = codeInput.replace(/\D/g, "");
    const saved = readRoom(code);
    if (!saved) {
      setJoinError("Доска с таким кодом не найдена");
      return;
    }
    if (!saved.access) {
      setJoinError("Репетитор ещё не разрешил подключение");
      return;
    }
    setJoinError("");
    setRoom(saved);
    setLocalElements(saved.elements);
  };

  const toggleAccess = () => {
    if (!room) return;
    publish({ ...room, access: !room.access, updatedAt: Date.now() });
  };

  const pointFromEvent = (event: ReactPointerEvent<SVGSVGElement | SVGElement>): Point => {
    const rect = svgRef.current!.getBoundingClientRect();
    return {
      x: Math.max(0, Math.min(BOARD_WIDTH, ((event.clientX - rect.left) / rect.width) * BOARD_WIDTH)),
      y: Math.max(0, Math.min(BOARD_HEIGHT, ((event.clientY - rect.top) / rect.height) * BOARD_HEIGHT)),
    };
  };

  const styleForTool = () => {
    if (tool === "pink") return { color: "#f64c9a", opacity: 0.3, width: 24 };
    if (tool === "blue") return { color: "#4199ef", opacity: 0.3, width: 24 };
    return { color: "#242582", opacity: 1, width: penWidth };
  };

  const startDrawing = (event: ReactPointerEvent<SVGSVGElement>) => {
    if (!room?.access && role === "student") return;
    if (tool === "select" || tool === "eraser") {
      setSelectedId(null);
      return;
    }
    event.currentTarget.setPointerCapture(event.pointerId);
    const point = pointFromEvent(event);
    const style = styleForTool();
    const type: DrawType = tool === "line" ? "line" : tool === "rect" ? "rect" : tool === "ellipse" ? "ellipse" : "path";
    const element: BoardElement = {
      id: `${Date.now()}-${Math.random()}`,
      type,
      points: type === "path" ? [point] : [point, point],
      ...style,
    };
    setLocalElements((current) => [...current, element]);
    setAction({ kind: "draw", id: element.id });
  };

  const movePointer = (event: ReactPointerEvent<SVGSVGElement>) => {
    if (!action) return;
    const point = pointFromEvent(event);
    setLocalElements((current) => current.map((element) => {
      if (element.id !== action.id) return element;
      if (action.kind === "draw") {
        return { ...element, points: element.type === "path" ? [...element.points, point] : [element.points[0], point] };
      }
      if (action.kind === "move") {
        const dx = point.x - action.start.x;
        const dy = point.y - action.start.y;
        return { ...element, points: action.original.map((original) => ({ x: original.x + dx, y: original.y + dy })) };
      }
      const width = Math.max(point.x - action.bounds.x, 8);
      const height = Math.max(point.y - action.bounds.y, 8);
      return {
        ...element,
        points: action.original.map((original) => ({
          x: action.bounds.x + ((original.x - action.bounds.x) / action.bounds.width) * width,
          y: action.bounds.y + ((original.y - action.bounds.y) / action.bounds.height) * height,
        })),
      };
    }));
  };

  const finishAction = () => {
    if (!action) return;
    setAction(null);
    commitElements();
  };

  const selectElement = (event: ReactPointerEvent<SVGElement>, element: BoardElement) => {
    event.stopPropagation();
    if (tool === "eraser") {
      const next = elementsRef.current.filter((current) => current.id !== element.id);
      setLocalElements(next);
      commitElements(next);
      return;
    }
    if (tool !== "select") return;
    svgRef.current?.setPointerCapture(event.pointerId);
    setSelectedId(element.id);
    setAction({ kind: "move", id: element.id, start: pointFromEvent(event), original: element.points.map((point) => ({ ...point })) });
  };

  const startResize = (event: ReactPointerEvent<SVGCircleElement>, element: BoardElement) => {
    event.stopPropagation();
    svgRef.current?.setPointerCapture(event.pointerId);
    const bounds = boundsOf(element);
    setAction({ kind: "resize", id: element.id, bounds, original: element.points.map((point) => ({ ...point })) });
  };

  const deleteSelected = () => {
    if (!selectedId) return;
    const next = elementsRef.current.filter((element) => element.id !== selectedId);
    setLocalElements(next);
    setSelectedId(null);
    commitElements(next);
  };

  const undo = () => {
    const next = elementsRef.current.slice(0, -1);
    setLocalElements(next);
    setSelectedId(null);
    commitElements(next);
  };

  const clear = () => {
    if (!window.confirm("Очистить всю доску?")) return;
    setLocalElements([]);
    setSelectedId(null);
    commitElements([]);
  };

  if (!room) {
    return (
      <div className="board-lobby">
        <div className="board-lobby-copy">
          <p className="eyebrow">Совместное занятие</p>
          <h2>Онлайн-доска</h2>
          <p>Доска в клетку для объяснений, схем и совместной работы в реальном времени.</p>
          <div className="board-feature-list"><span>Перо четырёх размеров</span><span>Два текстовыделителя</span><span>Линии и фигуры</span><span>Изменение размеров</span></div>
        </div>
        <div className="board-lobby-card">
          {role === "teacher" ? (
            <><span className="board-lobby-icon">+</span><h3>Начать новое занятие</h3><p>Создайте доску, разрешите доступ и отправьте ученику шестизначный код.</p><button className="primary-button" onClick={createRoom}>Создать доску</button></>
          ) : (
            <><span className="board-lobby-icon">→</span><h3>Подключиться к доске</h3><p>Введите код, который сообщил вам репетитор.</p><input className="board-code-input" value={codeInput} maxLength={6} onChange={(event) => setCodeInput(event.target.value.replace(/\D/g, ""))} placeholder="000 000" />{joinError && <div className="board-error">{joinError}</div>}<button className="primary-button" disabled={codeInput.length !== 6} onClick={joinRoom}>Войти на доску</button></>
          )}
        </div>
      </div>
    );
  }

  const selected = elements.find((element) => element.id === selectedId) ?? null;
  const selectedBounds = selected ? boundsOf(selected) : null;

  return (
    <div className="whiteboard-page">
      <header className="board-session-header">
        <div><p className="eyebrow">Совместная доска</p><h2>Занятие в клетку</h2></div>
        <div className="session-controls">
          <div className="session-code"><span>Код доски</span><b>{room.code}</b><button onClick={() => { navigator.clipboard?.writeText(room.code); setCopied(true); window.setTimeout(() => setCopied(false), 1500); }}>{copied ? "Скопировано" : "Копировать"}</button></div>
          {role === "teacher" && <button className={`access-button ${room.access ? "active" : ""}`} onClick={toggleAccess}><i />{room.access ? "Доступ открыт" : "Открыть доступ"}</button>}
          {role === "teacher" && <button className="new-board-button" onClick={() => { if (window.confirm("Создать новую доску? Текущая останется сохранена по старому коду.")) createRoom(); }}>Новая доска</button>}
          {role === "student" && <span className="live-badge"><i />На связи</span>}
        </div>
      </header>

      <div className="board-workspace">
        <div className="board-toolbar">
          <div className="tool-group">
            <button className={tool === "select" ? "active" : ""} onClick={() => setTool("select")}><b>↖</b><span>Выбор</span></button>
            <button className={tool === "pen" ? "active" : ""} onClick={() => setTool("pen")}><b>／</b><span>Перо</span></button>
            <div className="width-picker" title="Толщина пера">{PEN_WIDTHS.map((width) => <button className={penWidth === width ? "active" : ""} onClick={() => { setPenWidth(width); setTool("pen"); }} key={width}><i style={{ width: width + 3, height: width + 3 }} /></button>)}</div>
          </div>
          <div className="tool-group">
            <button className={tool === "pink" ? "active" : ""} onClick={() => setTool("pink")}><b className="pink-mark" /><span>Розовый</span></button>
            <button className={tool === "blue" ? "active" : ""} onClick={() => setTool("blue")}><b className="blue-mark" /><span>Синий</span></button>
          </div>
          <div className="tool-group">
            <button className={tool === "line" ? "active" : ""} onClick={() => setTool("line")}><b>╱</b><span>Линия</span></button>
            <button className={tool === "rect" ? "active" : ""} onClick={() => setTool("rect")}><b>□</b><span>Квадрат</span></button>
            <button className={tool === "ellipse" ? "active" : ""} onClick={() => setTool("ellipse")}><b>○</b><span>Круг</span></button>
          </div>
          <div className="tool-group board-actions">
            <button className={tool === "eraser" ? "active" : ""} onClick={() => setTool("eraser")}><b>⌫</b><span>Ластик</span></button>
            <button onClick={undo} disabled={!elements.length}><b>↶</b><span>Отменить</span></button>
            {selected && <button className="delete-tool" onClick={deleteSelected}><b>×</b><span>Удалить</span></button>}
            <button onClick={clear} disabled={!elements.length}><b>×</b><span>Очистить</span></button>
          </div>
        </div>

        <div className="board-canvas-wrap">
          {role === "student" && !room.access && <div className="board-locked"><b>Доступ закрыт</b><span>Попросите репетитора снова открыть доску.</span></div>}
          <svg
            ref={svgRef}
            className={`board-canvas tool-${tool}`}
            viewBox={`0 0 ${BOARD_WIDTH} ${BOARD_HEIGHT}`}
            preserveAspectRatio="none"
            onPointerDown={startDrawing}
            onPointerMove={movePointer}
            onPointerUp={finishAction}
            onPointerCancel={finishAction}
          >
            {elements.map((element) => {
              const common = { stroke: element.color, strokeWidth: element.width, opacity: element.opacity, fill: "none", strokeLinecap: "round" as const, strokeLinejoin: "round" as const, onPointerDown: (event: ReactPointerEvent<SVGElement>) => selectElement(event, element) };
              if (element.type === "path") return <path key={element.id} d={pathData(element.points)} {...common} />;
              const [start, end] = element.points;
              if (element.type === "line") return <line key={element.id} x1={start.x} y1={start.y} x2={end.x} y2={end.y} {...common} />;
              if (element.type === "rect") return <rect key={element.id} x={Math.min(start.x, end.x)} y={Math.min(start.y, end.y)} width={Math.abs(end.x - start.x)} height={Math.abs(end.y - start.y)} {...common} />;
              return <ellipse key={element.id} cx={(start.x + end.x) / 2} cy={(start.y + end.y) / 2} rx={Math.abs(end.x - start.x) / 2} ry={Math.abs(end.y - start.y) / 2} {...common} />;
            })}
            {selected && selectedBounds && <>
              <rect className="selection-box" x={selectedBounds.x - 7} y={selectedBounds.y - 7} width={selectedBounds.width + 14} height={selectedBounds.height + 14} />
              <circle className="resize-handle" cx={selectedBounds.x + selectedBounds.width + 7} cy={selectedBounds.y + selectedBounds.height + 7} r="9" onPointerDown={(event) => startResize(event, selected)} />
            </>}
          </svg>
          <div className="board-status"><span>{elements.length} объектов</span><span>{role === "teacher" ? "Репетитор" : "Ученик"}</span></div>
        </div>
      </div>
    </div>
  );
}
