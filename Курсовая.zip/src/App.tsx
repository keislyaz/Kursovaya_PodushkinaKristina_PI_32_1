import { FormEvent, ReactNode, useState } from "react";
import Whiteboard from "./Whiteboard";

type Role = "teacher" | "student";
type Screen =
  | "role"
  | "login"
  | "register"
  | "recover"
  | "new-password"
  | "reset-success"
  | "menu"
  | "students"
  | "student-form"
  | "progress"
  | "item-editor"
  | "tests"
  | "test-editor"
  | "test-runner"
  | "board";

type User = {
  id: number;
  login: string;
  password: string;
  secretWord: string;
  role: Role;
};

type Student = {
  id: number;
  fullName: string;
  phone: string;
  className: string;
  parentName: string;
  parentPhone: string;
};

type StudyItem = {
  id: number;
  studentId: number;
  name: string;
  grades: number[];
};

type TestQuestion = {
  id: number;
  text: string;
  options: string[];
  correct: number;
};

type TutorTest = {
  id: number;
  title: string;
  subject: string;
  questions: TestQuestion[];
  published: boolean;
};

const INITIAL_USERS: User[] = [
  { id: 1, login: "teacher", password: "1234", secretWord: "школа", role: "teacher" },
  { id: 2, login: "student", password: "1234", secretWord: "школа", role: "student" },
];

const INITIAL_STUDENTS: Student[] = [
  { id: 1, fullName: "Анна Смирнова", phone: "+7 918 245-18-10", className: "7А", parentName: "Елена Смирнова", parentPhone: "+7 918 320-44-51" },
  { id: 2, fullName: "Максим Волков", phone: "+7 988 632-07-14", className: "8Б", parentName: "Ольга Волкова", parentPhone: "+7 988 107-22-96" },
  { id: 3, fullName: "София Орлова", phone: "+7 918 441-60-08", className: "6А", parentName: "Алексей Орлов", parentPhone: "+7 918 806-71-35" },
];

const INITIAL_ITEMS: StudyItem[] = [
  { id: 1, studentId: 1, name: "Алгебра · Линейные уравнения", grades: [5, 4, 5, 5] },
  { id: 2, studentId: 1, name: "Геометрия · Треугольники", grades: [4, 5, 3] },
  { id: 3, studentId: 2, name: "Алгебра · Квадратные уравнения", grades: [4, 4, 5] },
  { id: 4, studentId: 3, name: "Математика · Дроби", grades: [5, 5, 4] },
];

const INITIAL_TESTS: TutorTest[] = [
  {
    id: 1,
    title: "Проверка знаний",
    subject: "Пример теста · Общие знания",
    published: true,
    questions: [
      { id: 1, text: "Сколько дней в високосном году?", options: ["365", "366", "364", "360"], correct: 1 },
      { id: 2, text: "Какой океан самый большой?", options: ["Атлантический", "Индийский", "Тихий", "Северный Ледовитый"], correct: 2 },
    ],
  },
];

function useStoredState<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : initial;
  });

  const update = (next: T | ((current: T) => T)) => {
    setValue((current) => {
      const result = typeof next === "function" ? (next as (current: T) => T)(current) : next;
      localStorage.setItem(key, JSON.stringify(result));
      return result;
    });
  };

  return [value, update] as const;
}

function Icon({ name, size = 22 }: { name: string; size?: number }) {
  const paths: Record<string, ReactNode> = {
    back: <path d="m15 18-6-6 6-6" />,
    home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v10h14V10M9 20v-6h6v6" /></>,
    teacher: <><path d="m3 11 9-7 9 7" /><path d="M5 10v10h14V10M9 20v-6h6v6" /></>,
    student: <><path d="m3 9 9-5 9 5-9 5-9-5Z" /><path d="M7 12v4c3 2 7 2 10 0v-4M21 9v6" /></>,
    arrow: <path d="m9 18 6-6-6-6" />,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" /></>,
    chart: <><path d="M4 20V10M10 20V4M16 20v-7M22 20H2" /></>,
    plus: <path d="M12 5v14M5 12h14" />,
    edit: <><path d="M12 20h9" /><path d="m16.5 3.5 4 4L8 20l-5 1 1-5Z" /></>,
    trash: <><path d="M3 6h18M8 6V4h8v2M19 6l-1 15H6L5 6M10 11v6M14 11v6" /></>,
    logout: <><path d="M10 17l5-5-5-5M15 12H3" /><path d="M14 3h7v18h-7" /></>,
    external: <><path d="M14 3h7v7M10 14 21 3" /><path d="M21 14v7H3V3h7" /></>,
    lock: <><rect x="4" y="10" width="16" height="11" rx="2" /><path d="M8 10V7a4 4 0 0 1 8 0v3" /></>,
    board: <><rect x="3" y="4" width="18" height="14" rx="2" /><path d="m8 21 4-3 4 3M8 9h8M8 13h5" /></>,
    quiz: <><path d="M9 11a3 3 0 1 1 4 2.83c-.64.28-1 .67-1 1.17" /><path d="M12 19h.01" /><rect x="3" y="2" width="18" height="20" rx="3" /></>,
  };
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>;
}

function Field({ label, ...props }: React.InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  return <label className="field"><span>{label}</span><input {...props} /></label>;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("role");
  const [history, setHistory] = useState<Screen[]>([]);
  const [role, setRole] = useState<Role | null>(null);
  const [users, setUsers] = useStoredState<User[]>("assistutor-users", INITIAL_USERS);
  const [students, setStudents] = useStoredState<Student[]>("assistutor-students", INITIAL_STUDENTS);
  const [items, setItems] = useStoredState<StudyItem[]>("assistutor-items", INITIAL_ITEMS);
  const [tests, setTests] = useStoredState<TutorTest[]>("assistutor-tests", INITIAL_TESTS);
  const [activeStudentId, setActiveStudentId] = useState<number | null>(null);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [editingItem, setEditingItem] = useState<StudyItem | null>(null);
  const [editingTest, setEditingTest] = useState<TutorTest | null>(null);
  const [activeTest, setActiveTest] = useState<TutorTest | null>(null);
  const [recoverUserId, setRecoverUserId] = useState<number | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [query, setQuery] = useState("");

  const navigate = (next: Screen) => {
    setHistory((current) => [...current, screen]);
    setScreen(next);
    setError("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const goBack = () => {
    setHistory((current) => {
      const copy = [...current];
      const previous = copy.pop() ?? "role";
      setScreen(previous);
      return copy;
    });
    setError("");
  };

  const goHome = () => {
    setScreen("role");
    setHistory([]);
    setRole(null);
    setError("");
  };

  const flashError = (message: string) => {
    setError(message);
    window.setTimeout(() => setError(""), 3000);
  };

  const chooseRole = (selectedRole: Role) => {
    setRole(selectedRole);
    navigate("login");
  };

  const selectedStudent = students.find((student) => student.id === activeStudentId) ?? null;

  const shell = (content: ReactNode, wide = false) => (
    <main className="app-shell" data-theme="electric">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      {screen !== "role" && (
        <nav className="top-nav" aria-label="Навигация">
          <button className="nav-button" onClick={goBack}><Icon name="back" size={19} />Назад</button>
          <button className="brand-mini" onClick={goHome} aria-label="AssisTutor — на главную"><span>A</span>AssisTutor</button>
          <button className="nav-button" onClick={goHome}><Icon name="home" size={18} />На главную</button>
        </nav>
      )}
      <section className={`page ${wide ? "page-wide" : ""}`}>{content}</section>
    </main>
  );

  if (screen === "role") {
    return shell(
      <div className="role-screen">
        <div className="hero-copy">
          <div className="logo-mark">A</div>
          <p className="eyebrow">Ваш помощник в обучении</p>
          <h1>Assis<span>Tutor</span></h1>
          <p className="hero-subtitle">Ученики, успеваемость, онлайн-доска и тесты — в одном пространстве для репетиторов по любому предмету.</p>
        </div>
        <div className="role-panel">
          <div className="panel-heading"><p>Добро пожаловать</p><h2>Как вы будете работать?</h2></div>
          <button className="role-card teacher-card" onClick={() => chooseRole("teacher")}>
            <span className="role-icon"><Icon name="teacher" size={28} /></span>
            <span><strong>Я репетитор</strong><small>Ученики, оценки и тесты</small></span>
            <Icon name="arrow" />
          </button>
          <button className="role-card student-card" onClick={() => chooseRole("student")}>
            <span className="role-icon"><Icon name="student" size={28} /></span>
            <span><strong>Я ученик</strong><small>Занятия и тесты</small></span>
            <Icon name="arrow" />
          </button>
          <p className="privacy"><Icon name="lock" size={14} />Данные хранятся только в вашем браузере</p>
        </div>
      </div>,
    );
  }

  if (screen === "login") {
    const submit = (event: FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      const user = users.find((candidate) => candidate.login === data.get("login") && candidate.password === data.get("password") && candidate.role === role);
      if (!user) return flashError("Проверьте логин, пароль и выбранную роль");
      navigate("menu");
    };
    return shell(
      <AuthCard title="С возвращением" subtitle={`Вход для ${role === "teacher" ? "репетитора" : "ученика"}`} error={error}>
        <form onSubmit={submit} className="form-stack">
          <Field label="Логин" name="login" placeholder="Введите логин" required autoFocus />
          <Field label="Пароль" name="password" type="password" placeholder="Введите пароль" required />
          <div className="demo-hint">Для просмотра: <b>{role}</b> / <b>1234</b></div>
          <button className="primary-button" type="submit">Войти <Icon name="arrow" size={18} /></button>
        </form>
        <button className="text-button" onClick={() => navigate("recover")}>Забыли пароль?</button>
        <div className="divider"><span>или</span></div>
        <button className="secondary-button" onClick={() => navigate("register")}>Зарегистрироваться</button>
      </AuthCard>,
    );
  }

  if (screen === "register") {
    const submit = (event: FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      const login = String(data.get("login")).trim();
      if (users.some((user) => user.login.toLowerCase() === login.toLowerCase())) return flashError("Такой логин уже занят");
      setUsers([...users, { id: Date.now(), login, password: String(data.get("password")), secretWord: String(data.get("secret")).trim().toLowerCase(), role: role! }]);
      setNotice("Аккаунт создан. Теперь войдите.");
      goBack();
    };
    return shell(
      <AuthCard title="Создать аккаунт" subtitle={`Регистрация для ${role === "teacher" ? "репетитора" : "ученика"}`} error={error}>
        <form onSubmit={submit} className="form-stack">
          <Field label="Логин" name="login" placeholder="Придумайте логин" required autoFocus />
          <Field label="Пароль" name="password" type="password" placeholder="Не менее 4 символов" minLength={4} required />
          <Field label="Кодовое слово" name="secret" placeholder="Для восстановления пароля" required />
          <button className="primary-button" type="submit">Зарегистрироваться</button>
        </form>
      </AuthCard>,
    );
  }

  if (screen === "recover") {
    const submit = (event: FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      const user = users.find((candidate) => candidate.login === String(data.get("login")).trim() && candidate.secretWord === String(data.get("secret")).trim().toLowerCase() && candidate.role === role);
      if (!user) return flashError("Логин или кодовое слово не совпадают");
      setRecoverUserId(user.id);
      navigate("new-password");
    };
    return shell(
      <AuthCard title="Восстановление пароля" subtitle="Шаг 1 из 2 · подтвердите аккаунт" error={error}>
        <form onSubmit={submit} className="form-stack">
          <Field label="Логин" name="login" placeholder="Ваш логин" required autoFocus />
          <Field label="Кодовое слово" name="secret" placeholder="Введите кодовое слово" required />
          <button className="primary-button" type="submit">Проверить</button>
        </form>
      </AuthCard>,
    );
  }

  if (screen === "new-password") {
    const submit = (event: FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      const password = String(new FormData(event.currentTarget).get("password"));
      setUsers(users.map((user) => user.id === recoverUserId ? { ...user, password } : user));
      navigate("reset-success");
    };
    return shell(
      <AuthCard title="Новый пароль" subtitle="Шаг 2 из 2 · задайте новый пароль" error={error}>
        <form onSubmit={submit} className="form-stack">
          <Field label="Новый пароль" name="password" type="password" placeholder="Не менее 4 символов" minLength={4} required autoFocus />
          <button className="primary-button" type="submit">Сохранить пароль</button>
        </form>
      </AuthCard>,
    );
  }

  if (screen === "reset-success") {
    return shell(
      <div className="success-card">
        <div className="success-check">✓</div>
        <p className="eyebrow">Готово</p>
        <h2>Пароль успешно изменён</h2>
        <p>Используйте новый пароль для входа в AssisTutor.</p>
        <button className="primary-button" onClick={() => navigate("login")}>Перейти ко входу</button>
      </div>,
    );
  }

  if (screen === "menu") {
    return shell(
      <div className="dashboard">
        <header className="dashboard-header">
          <div><p className="eyebrow">{role === "teacher" ? "Пространство репетитора" : "Пространство ученика"}</p><h2>Добрый день!</h2><p>Выберите, с чем хотите поработать сегодня.</p></div>
          <button className="logout-button" onClick={goHome}><Icon name="logout" size={18} />Выйти</button>
        </header>
        {notice && <div className="notice">{notice}<button onClick={() => setNotice("")}>×</button></div>}
        <div className="section-heading"><div><p className="eyebrow">Рабочее пространство</p><h3>{role === "teacher" ? "Инструменты репетитора" : "Инструменты ученика"}</h3></div><span>Всё необходимое для занятия</span></div>
        <div className={`management-grid ${role === "student" ? "student-tools" : ""}`}>
          {role === "teacher" && <button className="management-card" onClick={() => navigate("students")}><span><Icon name="users" size={27} /></span><div><strong>База учеников</strong><small>{students.length} учеников</small></div><Icon name="arrow" /></button>}
          {role === "teacher" && <button className="management-card coral" onClick={() => navigate("students")}><span><Icon name="chart" size={27} /></span><div><strong>Журнал успеваемости</strong><small>Предметы, темы и оценки</small></div><Icon name="arrow" /></button>}
          <button className="management-card board-card" onClick={() => navigate("board")}><span><Icon name="board" size={27} /></span><div><strong>Онлайн-доска</strong><small>Объясняйте материал вместе</small></div><Icon name="arrow" size={19} /></button>
          <button className="management-card test-card" onClick={() => navigate("tests")}><span><Icon name="quiz" size={27} /></span><div><strong>{role === "teacher" ? "Конструктор тестов" : "Мои тесты"}</strong><small>{tests.filter((test) => test.published).length} доступно</small></div><Icon name="arrow" /></button>
        </div>
      </div>, true,
    );
  }

  if (screen === "students") {
    const filtered = students.filter((student) => student.fullName.toLowerCase().includes(query.toLowerCase()));
    const remove = (id: number) => {
      if (!window.confirm("Удалить ученика и все его оценки?")) return;
      setStudents(students.filter((student) => student.id !== id));
      setItems(items.filter((item) => item.studentId !== id));
    };
    return shell(
      <div>
        <header className="content-header"><div><p className="eyebrow">Рабочий список</p><h2>Мои ученики</h2><p>Управляйте контактами и следите за успеваемостью.</p></div><button className="primary-button compact" onClick={() => { setEditingStudent(null); navigate("student-form"); }}><Icon name="plus" size={18} />Добавить</button></header>
        <div className="search-box"><Icon name="search" size={20} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Найти ученика по имени..." /><span>{filtered.length}</span></div>
        <div className="student-list">
          {filtered.map((student) => (
            <article className="student-card" key={student.id}>
              <div className="avatar">{student.fullName.split(" ").map((part) => part[0]).slice(0, 2).join("")}</div>
              <div className="student-main"><div className="student-title"><h3>{student.fullName}</h3><span>{student.className} класс</span></div><div className="contact-row"><span>Ученик: <b>{student.phone}</b></span><span>Родитель: {student.parentName}, <b>{student.parentPhone}</b></span></div></div>
              <div className="student-actions">
                <button className="icon-action" title="Изменить" onClick={() => { setEditingStudent(student); navigate("student-form"); }}><Icon name="edit" size={18} /></button>
                <button className="progress-button" onClick={() => { setActiveStudentId(student.id); navigate("progress"); }}><Icon name="chart" size={18} />Успеваемость</button>
                <button className="icon-action danger" title="Удалить" onClick={() => remove(student.id)}><Icon name="trash" size={18} /></button>
              </div>
            </article>
          ))}
          {filtered.length === 0 && <div className="empty-state"><Icon name="search" size={32} /><h3>Ничего не найдено</h3><p>Попробуйте изменить поисковый запрос.</p></div>}
        </div>
      </div>, true,
    );
  }

  if (screen === "student-form") {
    const submit = (event: FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      const student: Student = {
        id: editingStudent?.id ?? Date.now(),
        fullName: String(data.get("fullName")).trim(),
        phone: String(data.get("phone")).trim(),
        className: String(data.get("className")).trim(),
        parentName: String(data.get("parentName")).trim(),
        parentPhone: String(data.get("parentPhone")).trim(),
      };
      setStudents(editingStudent ? students.map((current) => current.id === student.id ? student : current) : [...students, student]);
      goBack();
    };
    return shell(
      <div className="editor-card">
        <p className="eyebrow">{editingStudent ? "Редактирование" : "Новая запись"}</p><h2>{editingStudent ? "Данные ученика" : "Добавить ученика"}</h2><p className="editor-intro">Заполните контактную информацию. Все поля можно изменить позже.</p>
        <form className="form-grid" onSubmit={submit}>
          <Field label="ФИО ученика" name="fullName" defaultValue={editingStudent?.fullName} placeholder="Иванов Иван" required autoFocus />
          <Field label="Класс" name="className" defaultValue={editingStudent?.className} placeholder="7А" required />
          <Field label="Телефон ученика" name="phone" defaultValue={editingStudent?.phone} placeholder="+7 900 000-00-00" required />
          <Field label="ФИО родителя" name="parentName" defaultValue={editingStudent?.parentName} placeholder="Иванова Анна" required />
          <Field label="Телефон родителя" name="parentPhone" defaultValue={editingStudent?.parentPhone} placeholder="+7 900 000-00-00" required />
          <div className="form-actions"><button type="button" className="secondary-button" onClick={goBack}>Отмена</button><button className="primary-button" type="submit">Сохранить</button></div>
        </form>
      </div>,
    );
  }

  if (screen === "progress" && selectedStudent) {
    const studentItems = items.filter((item) => item.studentId === selectedStudent.id);
    return shell(
      <div>
        <header className="content-header progress-header"><div><p className="eyebrow">Успеваемость · {selectedStudent.className} класс</p><h2>{selectedStudent.fullName}</h2><p>Темы занятий и полученные оценки.</p></div><button className="primary-button compact" onClick={() => { setEditingItem(null); navigate("item-editor"); }}><Icon name="plus" size={18} />Добавить тему</button></header>
        <div className="summary-row">
          <div><span>Тем изучено</span><strong>{studentItems.length}</strong></div>
          <div><span>Средний балл</span><strong>{studentItems.flatMap((item) => item.grades).length ? (studentItems.flatMap((item) => item.grades).reduce((a, b) => a + b, 0) / studentItems.flatMap((item) => item.grades).length).toFixed(1) : "—"}</strong></div>
          <div><span>Всего оценок</span><strong>{studentItems.flatMap((item) => item.grades).length}</strong></div>
        </div>
        <div className="topics-list">
          {studentItems.map((item) => (
            <button className="topic-row" key={item.id} onClick={() => { setEditingItem(item); navigate("item-editor"); }}>
              <span className="topic-icon"><Icon name="chart" size={20} /></span><span className="topic-name"><strong>{item.name}</strong><small>{item.grades.length} оценок</small></span>
              <span className="grades">{item.grades.map((grade, index) => <i className={`grade grade-${grade}`} key={`${grade}-${index}`}>{grade}</i>)}</span><Icon name="arrow" size={19} />
            </button>
          ))}
          {!studentItems.length && <div className="empty-state"><Icon name="chart" size={32} /><h3>Тем пока нет</h3><p>Добавьте первую тему занятия и оценки.</p></div>}
        </div>
      </div>, true,
    );
  }

  if (screen === "item-editor" && selectedStudent) {
    return <ItemEditor item={editingItem} student={selectedStudent} onCancel={goBack} onSave={(saved) => { setItems(editingItem ? items.map((item) => item.id === saved.id ? saved : item) : [...items, saved]); goBack(); }} onDelete={() => { if (editingItem) setItems(items.filter((item) => item.id !== editingItem.id)); goBack(); }} shell={shell} />;
  }

  if (screen === "tests") {
    const visibleTests = role === "teacher" ? tests : tests.filter((test) => test.published);
    const removeTest = (id: number) => {
      if (window.confirm("Удалить тест?")) setTests(tests.filter((test) => test.id !== id));
    };
    return shell(
      <div>
        <header className="content-header">
          <div><p className="eyebrow">{role === "teacher" ? "Конструктор" : "Задания"}</p><h2>{role === "teacher" ? "Мои тесты" : "Доступные тесты"}</h2><p>{role === "teacher" ? "Создавайте задания для учеников любого направления." : "Выберите тест и проверьте свои знания."}</p></div>
          {role === "teacher" && <button className="primary-button compact" onClick={() => { setEditingTest(null); navigate("test-editor"); }}><Icon name="plus" size={18} />Создать тест</button>}
        </header>
        <div className="test-grid">
          {visibleTests.map((test) => (
            <article className="test-list-card" key={test.id}>
              <div className="test-card-top"><span><Icon name="quiz" size={22} /></span>{role === "teacher" && <i className={test.published ? "published" : "draft"}>{test.published ? "Опубликован" : "Черновик"}</i>}</div>
              <p>{test.subject}</p><h3>{test.title}</h3><small>{test.questions.length} {test.questions.length === 1 ? "вопрос" : "вопросов"}</small>
              <div className="test-actions">
                {role === "teacher" ? <><button className="secondary-button" onClick={() => { setEditingTest(test); navigate("test-editor"); }}><Icon name="edit" size={16} />Изменить</button><button className="icon-action danger" title="Удалить" onClick={() => removeTest(test.id)}><Icon name="trash" size={17} /></button></> : <button className="primary-button" onClick={() => { setActiveTest(test); navigate("test-runner"); }}>Пройти тест <Icon name="arrow" size={16} /></button>}
              </div>
            </article>
          ))}
          {!visibleTests.length && <div className="empty-state test-empty"><Icon name="quiz" size={32} /><h3>Тестов пока нет</h3><p>{role === "teacher" ? "Создайте первый тест для своих учеников." : "Репетитор ещё не опубликовал задания."}</p></div>}
        </div>
      </div>, true,
    );
  }

  if (screen === "test-editor" && role === "teacher") {
    return <TestEditor test={editingTest} onCancel={goBack} onSave={(saved) => { setTests(editingTest ? tests.map((test) => test.id === saved.id ? saved : test) : [...tests, saved]); goBack(); }} shell={shell} />;
  }

  if (screen === "test-runner" && activeTest) {
    return <TestRunner test={activeTest} onBack={goBack} shell={shell} />;
  }

  if (screen === "board" && role) {
    return shell(<Whiteboard role={role} />, true);
  }

  return shell(<div className="empty-state"><h2>Страница не найдена</h2><button className="primary-button" onClick={goHome}>На главную</button></div>);
}

function AuthCard({ title, subtitle, error, children }: { title: string; subtitle: string; error: string; children: ReactNode }) {
  return <div className="auth-card"><div className="auth-logo">A</div><p className="eyebrow">AssisTutor</p><h2>{title}</h2><p className="auth-subtitle">{subtitle}</p>{error && <div className="error-message">{error}</div>}{children}</div>;
}

function ItemEditor({ item, student, onCancel, onSave, onDelete, shell }: { item: StudyItem | null; student: Student; onCancel: () => void; onSave: (item: StudyItem) => void; onDelete: () => void; shell: (content: ReactNode, wide?: boolean) => ReactNode }) {
  const [name, setName] = useState(item?.name ?? "");
  const [grades, setGrades] = useState<number[]>(item?.grades ?? []);
  const [grade, setGrade] = useState(5);
  return shell(
    <div className="editor-card topic-editor">
      <p className="eyebrow">{student.fullName}</p><h2>{item ? "Редактирование темы" : "Новая тема"}</h2><p className="editor-intro">{item ? "Измените название или добавьте новые оценки." : "Укажите предмет или тему занятия."}</p>
      <Field label="Название предмета / темы" value={name} onChange={(event) => setName(event.target.value)} placeholder="Например: Алгебра · Уравнения" autoFocus />
      <div className="grade-editor">
        <div><span className="input-label">Добавить оценку</span><div className="grade-pick">{[2, 3, 4, 5].map((value) => <button className={grade === value ? "active" : ""} key={value} onClick={() => setGrade(value)}>{value}</button>)}</div></div>
        <button className="secondary-button" onClick={() => setGrades([...grades, grade])}><Icon name="plus" size={17} />Добавить</button>
      </div>
      <div className="existing-grades"><span className="input-label">Существующие оценки</span><div>{grades.map((value, index) => <button title="Удалить оценку" className={`grade grade-${value}`} key={`${value}-${index}`} onClick={() => setGrades(grades.filter((_, gradeIndex) => gradeIndex !== index))}>{value}</button>)}{!grades.length && <small>Оценок пока нет</small>}</div></div>
      <div className="form-actions spread">{item ? <button className="delete-button" onClick={onDelete}><Icon name="trash" size={17} />Удалить тему</button> : <span />}<div><button className="secondary-button" onClick={onCancel}>Отмена</button><button className="primary-button" disabled={!name.trim()} onClick={() => onSave({ id: item?.id ?? Date.now(), studentId: student.id, name: name.trim(), grades })}>Сохранить</button></div></div>
    </div>,
  );
}

function TestEditor({ test, onCancel, onSave, shell }: { test: TutorTest | null; onCancel: () => void; onSave: (test: TutorTest) => void; shell: (content: ReactNode, wide?: boolean) => ReactNode }) {
  const [title, setTitle] = useState(test?.title ?? "");
  const [subject, setSubject] = useState(test?.subject ?? "");
  const [published, setPublished] = useState(test?.published ?? false);
  const [questions, setQuestions] = useState<TestQuestion[]>(test?.questions ?? [{ id: Date.now(), text: "", options: ["", "", "", ""], correct: 0 }]);
  const updateQuestion = (id: number, changes: Partial<TestQuestion>) => setQuestions(questions.map((question) => question.id === id ? { ...question, ...changes } : question));
  const updateOption = (question: TestQuestion, index: number, value: string) => {
    const options = [...question.options];
    options[index] = value;
    updateQuestion(question.id, { options });
  };
  const valid = title.trim() && subject.trim() && questions.every((question) => question.text.trim() && question.options.every((option) => option.trim()));

  return shell(
    <div>
      <header className="content-header"><div><p className="eyebrow">Конструктор тестов</p><h2>{test ? "Редактирование" : "Новый тест"}</h2><p>Добавьте вопросы и отметьте правильные ответы.</p></div></header>
      <div className="test-builder">
        <section className="editor-card test-settings">
          <Field label="Название теста" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Например: Итоговая проверка" autoFocus />
          <Field label="Предмет или направление" value={subject} onChange={(event) => setSubject(event.target.value)} placeholder="Английский язык · Уровень A2" />
          <label className="publish-toggle"><input type="checkbox" checked={published} onChange={(event) => setPublished(event.target.checked)} /><span /><div><b>Опубликовать тест</b><small>Он станет доступен ученикам</small></div></label>
        </section>
        <div className="questions-list">
          {questions.map((question, questionIndex) => (
            <section className="editor-card question-card" key={question.id}>
              <div className="question-heading"><span>Вопрос {questionIndex + 1}</span>{questions.length > 1 && <button onClick={() => setQuestions(questions.filter((current) => current.id !== question.id))}><Icon name="trash" size={17} /></button>}</div>
              <Field label="Текст вопроса" value={question.text} onChange={(event) => updateQuestion(question.id, { text: event.target.value })} placeholder="Введите вопрос" />
              <div className="options-grid">
                {question.options.map((option, optionIndex) => (
                  <label className={`option-edit ${question.correct === optionIndex ? "correct" : ""}`} key={optionIndex}>
                    <input type="radio" name={`correct-${question.id}`} checked={question.correct === optionIndex} onChange={() => updateQuestion(question.id, { correct: optionIndex })} />
                    <input value={option} onChange={(event) => updateOption(question, optionIndex, event.target.value)} placeholder={`Вариант ${optionIndex + 1}`} />
                  </label>
                ))}
              </div>
            </section>
          ))}
          <button className="add-question" onClick={() => setQuestions([...questions, { id: Date.now(), text: "", options: ["", "", "", ""], correct: 0 }])}><Icon name="plus" size={18} />Добавить вопрос</button>
        </div>
        <div className="builder-footer"><button className="secondary-button" onClick={onCancel}>Отмена</button><button className="primary-button" disabled={!valid} onClick={() => onSave({ id: test?.id ?? Date.now(), title: title.trim(), subject: subject.trim(), questions, published })}>Сохранить тест</button></div>
      </div>
    </div>, true,
  );
}

function TestRunner({ test, onBack, shell }: { test: TutorTest; onBack: () => void; shell: (content: ReactNode, wide?: boolean) => ReactNode }) {
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [finished, setFinished] = useState(false);
  const score = test.questions.filter((question) => answers[question.id] === question.correct).length;

  if (finished) {
    const percent = Math.round((score / test.questions.length) * 100);
    return shell(<div className="success-card test-result"><div className="result-ring">{percent}%</div><p className="eyebrow">Тест завершён</p><h2>{test.title}</h2><p>Правильных ответов: {score} из {test.questions.length}</p><button className="primary-button" onClick={onBack}>Вернуться к тестам</button></div>);
  }

  return shell(
    <div>
      <header className="content-header"><div><p className="eyebrow">{test.subject}</p><h2>{test.title}</h2><p>Выберите один ответ в каждом вопросе.</p></div><span className="answer-progress">{Object.keys(answers).length} / {test.questions.length}</span></header>
      <div className="runner-list">
        {test.questions.map((question, questionIndex) => (
          <section className="editor-card run-question" key={question.id}>
            <span>Вопрос {questionIndex + 1}</span><h3>{question.text}</h3>
            <div>{question.options.map((option, optionIndex) => <button className={answers[question.id] === optionIndex ? "selected" : ""} key={optionIndex} onClick={() => setAnswers({ ...answers, [question.id]: optionIndex })}><i>{String.fromCharCode(65 + optionIndex)}</i>{option}</button>)}</div>
          </section>
        ))}
      </div>
      <div className="runner-footer"><button className="primary-button" disabled={Object.keys(answers).length !== test.questions.length} onClick={() => setFinished(true)}>Завершить и узнать результат</button></div>
    </div>, true,
  );
}
